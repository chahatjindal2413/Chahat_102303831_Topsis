\## Project Description



Topsis-Chahat-102303831



For: Project-1 (UCS633)

Submitted by: Chahat  

Roll No: 102303831



Topsis-Chahat-102303831 is a Python package for solving Multiple Criteria Decision Making (MCDM) problems using the Technique for Order of Preference by Similarity to Ideal Solution (TOPSIS).  

The package ranks alternatives based on their distance from the ideal best and ideal worst solutions.



---



Installation:



Install the package using pip:



pip install Topsis-Chahat-102303831



---



Usage



Provide the input file name, followed by the weights vector, impacts vector, and the output file name.



topsis data.xlsx "1,1,1,1,1" "+,+,+,+,+" output.csv



Vectors can also be entered without double quotes:



topsis data.xlsx 1,1,1,1,1 +,+,+,+,+ output.csv



If the vectors contain spaces, they must be enclosed in double quotes.



To view help:



topsis /h



---



Example



Input File (data.xlsx)



| Fund Name | P1   | P2  | P3  | P4   | P5   |

|---------- |----- |-----|---- |----- |------|

| M1        | 0.62 | 0.38| 7.0 | 42.6 | 12.65|

| M2        | 0.79 | 0.62| 4.8 | 65.5 | 17.93|

| M3        | 0.75 | 0.56| 4.6 | 63.7 | 17.40|

| M4        | 0.78 | 0.61| 4.9 | 66.3 | 18.15|

| M5        | 0.61 | 0.37| 6.4 | 32.3 | 9.92 |

| M6        | 0.78 | 0.61| 4.2 | 45.4 | 12.75|

| M7        | 0.90 | 0.81| 3.5 | 63.3 | 17.13|

| M8        | 0.63 | 0.40| 4.1 | 61.7 | 16.71|



Weights vector = \[ 1 , 1 , 1 , 1 , 1 ]  

Impacts vector = \[ + , + , + , + , + ]



---



Input Command



topsis data.xlsx "1,1,1,1,1" "+,+,+,+,+" output.csv



---



Output (output.csv)



| Fund Name | P1   | P2   | P3  | P4   | P5    | Topsis Score | Rank |

|---------- |---- -|----- |---- |----- |------ |--------------|------|

| M1        | 0.84 | 0.71 | 6.7 | 42.1 | 12.59 | 0.563692     | 3    |

| M2        | 0.91 | 0.83 | 7.0 | 31.7 | 10.11 | 0.513032     | 4    |

| M3        | 0.79 | 0.62 | 4.8 | 46.7 | 13.23 | 0.439177     | 6    |

| M4        | 0.78 | 0.61 | 6.4 | 42.4 | 12.55 | 0.491956     | 5    |

| M5        | 0.94 | 0.88 | 3.6 | 62.2 | 16.91 | 0.641886     | 2    |

| M6        | 0.88 | 0.77 | 6.5 | 51.5 | 14.91 | 0.738148     | 1    |

| M7        | 0.66 | 0.44 | 5.3 | 48.9 | 13.83 | 0.407390     | 8    |

| M8        | 0.93 | 0.86 | 3.4 | 37.0 | 10.55 | 0.408499     | 7    |



---





Notes



\- The first column represents the alternatives and is not used in calculations.

\- All criteria columns must contain numeric values only.

\- The number of weights, impacts, and criteria columns must be equal.

\- The input file must contain at least three columns.



---



License



MIT



